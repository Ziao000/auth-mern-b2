import CreateShopForm from "../../components/form/CreateShopForm";

const CreateShopPage = () => {
    return ( 
        <>
        <h1>Create Shop</h1>
        <CreateShopForm/>
        </>
     );
}
 
export default CreateShopPage;