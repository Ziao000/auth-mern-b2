
# TODO 1
Update user informations (firstName, lastName, password)
### api
- create user router
- create update route
- create user controller
- don't change email

### front
- show form update user with auto complet (exlude password)

# TODO 2
Create shop

### api
- create method and route get all shops
- add attributes : imageUrl, description, location
### front
- create shop form
- create service shop
- create page list shop
- single page shop



# TODO 3
page my shops (filter by user)
update/delete shop if owner

# TODO 4
