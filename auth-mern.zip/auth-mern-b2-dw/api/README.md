npm i express dotenv mongoose cors
npm i -D nodemon




https://github.com/casey/just